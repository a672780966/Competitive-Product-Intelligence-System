# CPIS Phase I-Reset — Node 11: Hermes Skills Report

## Overview

Created 5 Hermes skills that expose CPIS capabilities to agents. Each skill covers one major CPIS feature and follows the standard Hermes skill format with YAML frontmatter, structured Markdown body, API reference, pitfalls, and verification steps.

## Skills Created

| # | Skill | Directory | Description |
|---|-------|-----------|-------------|
| 1 | cpis-discovery | `~/.hermes/skills/cpis-discovery/SKILL.md` | Source discovery — create sessions, list candidates, promote to templates |
| 2 | cpis-collection-template | `~/.hermes/skills/cpis-collection-template/SKILL.md` | Collection template management — create, list, run, update |
| 3 | cpis-scheduled-collection | `~/.hermes/skills/cpis-scheduled-collection/SKILL.md` | Schedule management — create, enable, disable schedules |
| 4 | cpis-feishu-sync | `~/.hermes/skills/cpis-feishu-sync/SKILL.md` | Feishu sync monitoring — check status, trigger syncs |
| 5 | cpis-usage | `~/.hermes/skills/cpis-usage/SKILL.md` | Usage query — daily stats, summary reports |

## Design Principles

All skills follow these core rules:

1. **Agent does NOT scrape** — All data collection is delegated to CPIS's built-in collectors
2. **Agent does NOT manage cron** — All scheduling is managed by CPIS's Celery Beat scheduler
3. **Agent does NOT write to Feishu** — All Feishu writes are handled by CPIS's FeishuSyncService
4. **Agent does NOT modify usage data** — Usage API is read-only

## Skill Format

Each skill includes:

- **YAML Frontmatter**: name, title, description, version, author, tags, triggers
- **Overview**: Purpose and core principle
- **When to Use**: Scenario table for matching user intent
- **Workflow**: Numbered steps with API examples and expected responses
- **Example Session**: Realistic dialogue between user and agent
- **Pitfalls**: Table of common mistakes with prevention strategies
- **API Reference**: Complete endpoint table
- **Verification**: Post-operation checks

## API Endpoints Referenced

| API Module | Endpoints Used |
|------------|---------------|
| Discovery | `POST /sessions`, `GET /sessions`, `GET /sessions/{id}`, `GET /sessions/{id}/candidates`, `PATCH /candidates/{id}`, `POST /sessions/{id}/select`, `POST /sessions/{id}/create-template` |
| Collection Templates | `GET /collection-templates`, `GET /collection-templates/{id}`, `PATCH /collection-templates/{id}`, `POST /collection-templates/{id}/run` |
| Scheduled Collections | `GET /scheduled-collections`, `POST /scheduled-collections`, `GET /scheduled-collections/{id}`, `PATCH /scheduled-collections/{id}` |
| Sync Records | `GET /sync-records`, `GET /sync-records/{id}`, `POST /sync-records/sync-product/{product_id}`, `POST /sync-records/sync-all` |
| Usage | `GET /usage/daily`, `GET /usage/summary` |

## Verification

All 5 skills created successfully with proper format and complete content. Skills are structured for both human readability and agent consumption.
