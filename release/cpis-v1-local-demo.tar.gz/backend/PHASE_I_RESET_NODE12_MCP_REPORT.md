# CPIS Phase I-Reset — Node 12: MCP Server Report

## Overview

Created a minimal stdio-based MCP (Model Context Protocol) server that exposes CPIS backend capabilities as MCP tools. The server uses JSON-RPC 2.0 over stdio transport with zero external MCP framework dependencies.

## Files Created

| File | Purpose |
|------|---------|
| `backend/mcp_server.py` | MCP server implementation |
| `backend/mcp_config.example.json` | Configuration template |

## Architecture

```
┌──────────────┐     JSON-RPC 2.0      ┌──────────────┐     HTTP      ┌──────────────┐
│ MCP Agent    │  ──── stdio ──────▶  │ MCP Server   │  ──────────▶ │ CPIS Backend │
│ (Claude,     │  ◀──────────────────│ (mcp_server) │  ◀──────────│ (FastAPI)     │
│  Codex, etc) │                      │              │              │ localhost:8000│
└──────────────┘                      └──────────────┘              └──────────────┘
```

## Tools Exposed

| # | Tool Name | Description | Required Params |
|---|-----------|-------------|-----------------|
| 1 | `cpis_discover` | Create a discovery session — finds competitor product sources | `query` |
| 2 | `cpis_get_candidates` | Get discovered source candidates from a session | `session_id` |
| 3 | `cpis_select_candidates` | Batch select/deselect source candidates | `session_id`, `candidate_ids` |
| 4 | `cpis_create_template` | Create a collection template from session selection | `session_id`, `name` |
| 5 | `cpis_run_template` | Execute a collection template immediately | `template_id` |
| 6 | `cpis_create_schedule` | Create a scheduled collection on a recurring schedule | `template_id`, `schedule_type` |
| 7 | `cpis_query_usage` | Query system usage statistics | `metric` |

## MCP Protocol Support

- **`initialize`** — Protocol handshake with capabilities negotiation
- **`notifications/initialized`** — Post-init notification (no response)
- **`tools/list`** — Returns all 7 tools with JSON Schema input definitions
- **`tools/call`** — Executes a tool and returns results
- **`ping`** — Keepalive health check

## Design Decisions

1. **No external MCP framework** — Pure stdlib + httpx for HTTP calls to CPIS backend
2. **Async implementation** — Uses httpx.AsyncClient for non-blocking API calls
3. **Error propagation** — API errors are captured and returned as structured MCP error responses
4. **No embedded secrets** — All credentials live in the CPIS backend's `.env`; MCP server only needs the CPIS API URL
5. **Configurable via environment** — `CPIS_API_BASE`, `CPIS_API_PREFIX`, `CPIS_MCP_TIMEOUT` env vars

## Configuration

```bash
# Default (backed at localhost:8000)
python3 mcp_server.py

# Custom backend URL
CPIS_API_BASE=https://cpis.example.com python3 mcp_server.py
```

## Agent Integration Examples

### Claude Code
```bash
claude --mcp-servers '{"cpis": {"command": "python3", "args": ["/path/to/mcp_server.py"]}}'
```

### Codex CLI
```bash
codex mcp --command 'python3 /path/to/mcp_server.py'
```

## Testing Results

- `tools/list` → Returns 7 tools with full JSON Schema ✓
- `initialize` → Returns server info and capabilities ✓
- `tools/call` → Correctly proxies to CPIS backend ✓
- `tools/call` (unknown tool) → Returns error response ✓
- Unknown method → Returns `-32601 Method not found` ✓

## Dependencies

- Python 3.12+
- `httpx` — HTTP client for CPIS API calls (install via `pip install httpx` or `poetry add httpx`)
