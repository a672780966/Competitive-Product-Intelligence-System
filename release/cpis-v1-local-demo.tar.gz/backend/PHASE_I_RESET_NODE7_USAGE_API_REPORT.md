# PHASE I-RESET — Node 7: Usage API Report

## Status: COMPLETE ✅

## Summary

Implemented the Usage API (Node 7) for CPIS Phase I-Reset — simple daily usage statistics without billing or approval workflows.

## Files Created

| File | Purpose |
|------|---------|
| `app/repositories/usage_repository.py` | Data access layer — upsert (create/accumulate), date-range query, aggregated summary |
| `app/schemas/usage.py` | Pydantic request/response schemas — `UsageDailyStatResponse`, `UsageDailyStatListResponse`, `UsageSummaryResponse` |
| `app/services/usage_service.py` | Business logic — `record_usage()`, `get_daily_stats()`, `get_summary()` |
| `app/api/usage.py` | FastAPI API routes — `GET /api/v1/usage/daily`, `GET /api/v1/usage/summary` |
| `tests/test_usage_api.py` | 21 tests covering service, repository, and API endpoint layers |

## Files Modified

| File | Change |
|------|--------|
| `app/main.py` | Registered `usage_router` with prefix `/api/v1/usage` |

## API Endpoints

### `GET /api/v1/usage/daily`
- Returns daily usage stats within an optional date range
- Defaults to last 30 days if no dates provided
- Query parameters: `date_from` (ISO date), `date_to` (ISO date)
- Response: `{ items: UsageDailyStat[], total: int, date_from, date_to }`

### `GET /api/v1/usage/summary`
- Returns aggregated totals across all daily records
- Optional `date_from` / `date_to` filter
- Response: `{ total_task_count, total_token_count, total_search_count, total_collected_page_count, total_success_count, total_failure_count, total_estimated_cost, total_days }`

## Service API

### `UsageService.record_usage()`
- Increments counters for a given date (default: today)
- Callable from DiscoveryService (`search_count=1`) and collection runner
- All values are additive — multiple calls accumulate

### `UsageService.get_daily_stats()`
- Lists daily stats within a date range

### `UsageService.get_summary()`
- Aggregated totals across all records

## Test Results

```
149 passed (128 existing + 21 new usage tests)
```

- **21 new tests** (all passing):
  - 7 service-layer tests (record_usage create/accumulate, daily stats, summary)
  - 5 repository-layer tests (upsert create/accumulate, get_by_date, get_daily_stats, summary)
  - 9 API endpoint tests (daily stats empty/data/filter, summary empty/data/fields)

- **128 existing tests remain passing** (no regressions from product, review, sync, openclaw, discovery, collection_templates, scheduled_collections)

## Integration Points (for later nodes)

- **DiscoveryService**: Call `usage_service.record_usage(search_count=1)` after search
- **Collection runner**: Call `usage_service.record_usage(task_count=1, token_count=N, success_count=1)` when tasks complete
- These are NOT implemented yet — just the service/API layer is ready

## Critical Rules Followed

- ❌ No billing or approval workflows implemented
- ✅ Mock provider pattern for tests (SQLite in-memory)
- ✅ 128 existing tests still pass
- ✅ Repository pattern for DB access
- ✅ Pydantic schemas for all API input/output
