# Phase I-Reset — Node 0: Repo Baseline

> **Generated**: 2026-06-26
> **Run ID**: run_20260626_phase_i_reset_n0

---

## 1. Git

| Item | Value |
|------|-------|
| Branch | `main` |
| Head | `3fca005` — "fix(cpis): Feishu Bitable search field_names fix + test adaptation" |
| Author | ctyun <a672780966@gmail.com> |
| Date | Fri Jun 26 00:21:17 2026 +0800 |
| Status | 2 modified, 30+ untracked (docs/reports) |
| Remote | origin/main, origin/feat/fix-audit-13-issues |
| Push/Tag/Merge | ✅ 未执行 |

## 2. Backend

| Item | Value |
|------|-------|
| **Tests** | **248 passed** (1 warning) |
| **Alembic head** | `002_align_fields` |
| **Uvicorn** | ✅ Running (port 8000) |
| **PostgreSQL** | ✅ Docker (5432) |
| **Redis** | ✅ Docker (6379) |
| **Celery worker** | ✅ Running (pool=solo) |
| **OpenClaw Bridge** | ✅ `POST /api/v1/openclaw/evidence` |

## 3. API Routes

Existing:
- `/` — root
- `/health/live`, `/health/ready` — health
- `/api/v1/collection-tasks` (+ batch, /{id}, events, retry, cancel, snapshots)
- `/api/v1/products` (/products/{id}, /versions)
- `/api/v1/reviews` (/reviews/{version_id}, approve, reject, draft)
- `/api/v1/reports/compare`, `/api/v1/reports/product/{product_id}`
- `/api/v1/sync-records` (list, detail, sync-product/{id}, sync-all)
- `/api/v1/openclaw/evidence`

**Missing** (needed for Phase I-Reset):
- `/api/v1/discovery/*` — Source discovery
- `/api/v1/collection-templates/*` — Collection templates
- `/api/v1/scheduled-collections/*` — Scheduled collections
- `/api/v1/usage/*` — Usage stats

## 4. Frontend

| Item | Value |
|------|-------|
| **Build** | ✅ tsc + vite build pass |
| **Pages** | /tasks, /tasks/:id, /products, /products/:id, /reviews, /reviews/:versionId, /sync, /reports |
| **Features** | tasks/, products/, reviews/, sync/, reports/ |

**Missing pages**:
- `/discovery` — Source Discovery UI
- `/collection-templates` — Template/Scheduler UI
- `/usage` — Usage Chart

## 5. Database Models

| Model | Table | Status |
|-------|-------|--------|
| CollectionTask | collection_tasks | ✅ |
| TaskEvent | task_events | ✅ |
| SourceSnapshot | source_snapshots | ✅ |
| Product | products | ✅ |
| ProductVersion | product_versions | ✅ |
| ProductEvidence | product_evidences | ✅ |
| ReviewRecord | review_records | ✅ |
| FeishuSyncRecord | feishu_sync_records | ✅ |
| AuditLog | audit_logs | ✅ |
| PromptTemplate | prompt_templates | ✅ |

**Needed**: DiscoverySession, SourceCandidate, CollectionTemplate, ScheduledCollection, UsageDailyStat

## 6. Existing Integrations

| Integration | Type | Status |
|-------------|------|--------|
| Feishu Bitable | sync | ✅ 真实写入成功 (3 records from Phase I) |
| OpenClaw Gateway | external | ✅ Running, bridge endpoint live |
| cpis-json-gate | plugin | ✅ Loaded |
| Agent rules | policies | ✅ Deployed (collector/analyst/curator) |

## 7. OpenClaw Decoupling State

| Component | Status | Phase I-Reset Plan |
|-----------|--------|-------------------|
| `/api/v1/openclaw/evidence` | ✅ Live | ✅ **保留** as external adapter |
| OpenClaw as main collector | ❌ Was primary | ❌ **降级** for Phase I-Reset |
| cpis-json-gate plugin | ✅ Loaded | ✅ **保留** for external evidence |
| Agent rules (3 agents) | ✅ Deployed | ✅ **保留** for optional use |
| New built-in collector | ❌ Not exists | ✅ **新建** as primary path |

## 8. Skills

| File | Path |
|------|------|
| Not available — will create | `~/.hermes/skills/` |

## 9. Gate

| Check | Status |
|-------|--------|
| No .env committed | ✅ `.env` gitignored + chmod 600 |
| No secrets printed | ✅ Not in code |
| No push/tag/merge | ✅ |
| Tests pass (248) | ✅ |
| Frontend build | ✅ |
| Docker running | ✅ |
| Celery running | ✅ |
| Alembic at head | ✅ |

## 10. Verdict

```
NODE0_PASS
```
