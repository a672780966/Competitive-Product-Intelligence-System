from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import PostgresDsn, RedisDsn
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings — loaded from env / .env file."""

    model_config = SettingsConfigDict(
        env_file=os.fspath(Path(__file__).parents[3] / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- General ---
    APP_NAME: str = "CPIS V1"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = False
    ENVIRONMENT: Literal["development", "staging", "production"] = "development"

    # --- Server ---
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # --- Database ---
    DATABASE_URL: PostgresDsn | str = "postgresql+asyncpg://cpis:cpis@localhost:5432/cpis"
    DATABASE_ECHO: bool = False

    # --- Redis ---
    REDIS_URL: RedisDsn | str = "redis://localhost:6379/0"

    # --- Celery ---
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # --- AI (LLM) ---
    LLM_PROVIDER: str = "stub"          # stub | openai | gemini | claude | deepseek | qwen
    LLM_API_KEY: str = ""
    LLM_MODEL: str = "gpt-4o"
    LLM_BASE_URL: str = ""

    # --- Search Provider ---
    SEARCH_PROVIDER: str = "duckduckgo"

    # --- Cache ---
    CACHE_ENABLED: bool = True
    CACHE_TTL_SECONDS: int = 300

    # --- Feishu ---
    FEISHU_APP_ID: str = ""
    FEISHU_APP_SECRET: str = ""
    FEISHU_BITABLE_TOKEN: str = ""
    FEISHU_TABLE_ID: str = ""
    FEISHU_VIEW_ID: str = ""
    # --- Collection ---
    COLLECTION_TIMEOUT_SECONDS: int = 60
    COLLECTION_MAX_RETRIES: int = 3
    COLLECTION_USER_AGENT: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0.0.0 Safari/537.36"
    )

    # --- Collector Feature Flags ---
    COLLECTOR_PLAYWRIGHT_ENABLED: bool = False
    COLLECTOR_SCRAPLING_ENABLED: bool = False
    COLLECTOR_CRAWL4AI_ENABLED: bool = False
    COLLECTOR_RSS_ENABLED: bool = False
    COLLECTOR_PDF_ENABLED: bool = False
    COLLECTOR_API_ENABLED: bool = False

    # --- Review ---
    REVIEW_CONFIDENCE_THRESHOLD: float = 0.7


@lru_cache()
def get_settings() -> Settings:
    """Return a cached singleton Settings instance."""
    return Settings()
