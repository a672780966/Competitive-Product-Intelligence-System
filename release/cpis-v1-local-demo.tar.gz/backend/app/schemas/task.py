"""CPIS V1 — Task schemas for API request/response."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from pydantic import BaseModel, Field, field_validator

from app.models.enums import TaskPriority, TaskStatus
from app.schemas.collector_execution_report import CollectorExecutionReportResponse


# ── Request schemas ─────────────────────────────────────────────


class CreateTaskRequest(BaseModel):
    """Request body for creating a single collection task."""

    source_url: str = Field(..., max_length=2048, min_length=1, description="The URL to collect")
    category_hint: str | None = Field(None, max_length=64)
    language_hint: str | None = Field(None, max_length=16)
    priority: TaskPriority = Field(default=TaskPriority.NORMAL)
    auto_sync_feishu: bool = Field(default=False)
    created_by: str | None = Field(None, max_length=128)


class BatchCreateTaskRequest(BaseModel):
    """Request body for batch-creating collection tasks."""

    tasks: list[CreateTaskRequest] = Field(..., min_length=1, max_length=100)


class TaskListQuery(BaseModel):
    """Query parameters for listing tasks."""

    status: TaskStatus | None = None
    domain: str | None = None
    keyword: str | None = Field(None, description="Search in source_url")
    priority: TaskPriority | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)

    @field_validator("date_from", "date_to")
    @classmethod
    def ensure_timezone(cls, v: datetime | None) -> datetime | None:
        if v is not None and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


# ── Response schemas ────────────────────────────────────────────


class TaskEventResponse(BaseModel):
    """Single task event for API response."""

    id: uuid.UUID
    stage: str
    status: str
    message: str | None
    duration_ms: int | None
    error_code: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class TaskResponse(BaseModel):
    """Collection task detail for API response."""

    id: uuid.UUID
    source_url: str
    normalized_url: str | None = None
    domain: str | None = None
    status: str
    priority: int
    category_hint: str | None = None
    language_hint: str | None = None
    auto_sync_feishu: bool
    retry_count: int
    max_retries: int
    error_code: str | None = None
    error_message: str | None = None
    created_by: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class SnapshotResponse(BaseModel):
    id: uuid.UUID
    task_id: uuid.UUID
    final_url: str | None
    html_hash: str | None
    content_hash: str | None
    cleaned_text: str | None
    cleaned_markdown: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class PipelineStageStatus(BaseModel):
    stage: str
    status: str
    error_code: str | None = None
    error_message: str | None = None


class PipelineStatusResponse(BaseModel):
    stages: list[PipelineStageStatus] = []
    current_stage: str | None = None
    overall_status: str
    retry_count: int = 0
    max_retries: int = 3


class TaskDetailResponse(TaskResponse):
    """Task detail including event history, snapshot, pipeline status, and execution reports."""

    events: list[TaskEventResponse] = []
    execution_reports: list[CollectorExecutionReportResponse] = []
    snapshot: SnapshotResponse | None = None
    pipeline_status: PipelineStatusResponse | None = None


class PaginatedTaskResponse(BaseModel):
    """Paginated list of tasks."""

    items: list[TaskResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


class BatchCreateTaskResponse(BaseModel):
    """Response for batch creation."""

    created: int
    tasks: list[TaskResponse]
    errors: list[dict] = Field(default_factory=list)
