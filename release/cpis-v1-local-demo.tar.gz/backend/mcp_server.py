#!/usr/bin/env python3
"""
CPIS MCP Server — Minimal stdio-based Model Context Protocol server.

Exposes CPIS backend capabilities as MCP tools for any MCP-compatible agent
(Claude Code, Codex, OpenCode, etc.).

Transport: stdio (JSON-RPC 2.0)
Dependencies: httpx (stdlib: json, sys, os, uuid)
No external MCP framework required.

Usage:
    python3 mcp_server.py

    Or pipe via stdio for MCP-compatible agents:
    echo '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | python3 mcp_server.py
"""

from __future__ import annotations

import json
import os
import sys
import uuid
from typing import Any

import httpx

# ── Configuration ──────────────────────────────────────────────────────────────

CPIS_API_BASE = os.environ.get("CPIS_API_BASE", "http://localhost:8000")
CPIS_API_PREFIX = os.environ.get("CPIS_API_PREFIX", "/api/v1")
HTTP_TIMEOUT = int(os.environ.get("CPIS_MCP_TIMEOUT", "30"))

# ── MCP Server Info ────────────────────────────────────────────────────────────

SERVER_INFO = {
    "name": "cpis-mcp-server",
    "version": "1.0.0",
    "description": "CPIS (Competitive Product Intelligence System) MCP tools",
}

# ── Tool Definitions ───────────────────────────────────────────────────────────

TOOLS: list[dict[str, Any]] = [
    {
        "name": "cpis_discover",
        "description": (
            "Create a discovery session to find competitor product sources. "
            "Returns candidates with titles, URLs, domains, and risk levels. "
            "Candidates can later be promoted to collection templates."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query or URL to discover sources from",
                },
                "target_brand": {
                    "type": "string",
                    "description": "Optional brand name to target",
                },
                "topic": {
                    "type": "string",
                    "description": "Optional topic or category hint",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "cpis_get_candidates",
        "description": (
            "Get discovered source candidates from a discovery session. "
            "Returns paginated list of candidates with their selection status."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Discovery session UUID",
                },
                "page": {
                    "type": "integer",
                    "default": 1,
                    "description": "Page number",
                },
                "page_size": {
                    "type": "integer",
                    "default": 20,
                    "description": "Items per page (max 100)",
                },
            },
            "required": ["session_id"],
        },
    },
    {
        "name": "cpis_select_candidates",
        "description": (
            "Batch select or deselect source candidates in a discovery session. "
            "Selected candidates can later be used to create a collection template."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Discovery session UUID",
                },
                "candidate_ids": {
                    "type": "array",
                    "items": {"type": "string", "format": "uuid"},
                    "description": "List of candidate UUIDs to select/deselect",
                    "minItems": 1,
                },
                "selected": {
                    "type": "boolean",
                    "default": True,
                    "description": "True to select, False to deselect",
                },
            },
            "required": ["session_id", "candidate_ids"],
        },
    },
    {
        "name": "cpis_create_template",
        "description": (
            "Create a collection template from a discovery session's selected candidates. "
            "The template can then be run immediately or scheduled for recurring collection."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Discovery session UUID with selected candidates",
                },
                "name": {
                    "type": "string",
                    "description": "Template name",
                },
                "description": {
                    "type": "string",
                    "description": "Optional template description",
                },
                "feishu_sync_enabled": {
                    "type": "boolean",
                    "default": False,
                    "description": "Enable auto-sync to Feishu",
                },
            },
            "required": ["session_id", "name"],
        },
    },
    {
        "name": "cpis_run_template",
        "description": (
            "Execute a collection template immediately. Creates CollectionTasks "
            "for all sources defined in the template's source plan."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Collection template UUID to execute",
                },
            },
            "required": ["template_id"],
        },
    },
    {
        "name": "cpis_create_schedule",
        "description": (
            "Create a scheduled collection that runs a template on a recurring schedule. "
            "Supports daily, weekly, hourly, custom cron, or interval-based schedules."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Collection template UUID to schedule",
                },
                "schedule_type": {
                    "type": "string",
                    "enum": ["daily", "weekly", "hourly", "custom_cron", "interval"],
                    "description": "Type of schedule",
                },
                "cron_expr": {
                    "type": "string",
                    "description": "Cron expression (required if schedule_type=custom_cron)",
                },
                "interval_minutes": {
                    "type": "integer",
                    "description": "Interval in minutes (required if schedule_type=interval, 1-44640)",
                },
                "enabled": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether the schedule is active on creation",
                },
                "max_failures_before_pause": {
                    "type": "integer",
                    "default": 3,
                    "description": "Max consecutive failures before auto-pausing",
                },
            },
            "required": ["template_id", "schedule_type"],
        },
    },
    {
        "name": "cpis_query_usage",
        "description": (
            "Query CPIS system usage statistics. Returns daily breakdown or "
            "aggregated summary of tasks, tokens, searches, and estimated costs."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "metric": {
                    "type": "string",
                    "enum": ["daily", "summary"],
                    "description": "Metric type: 'daily' for per-day breakdown, 'summary' for totals",
                },
                "date_from": {
                    "type": "string",
                    "format": "date",
                    "description": "Start date (YYYY-MM-DD, defaults to 30 days ago)",
                },
                "date_to": {
                    "type": "string",
                    "format": "date",
                    "description": "End date (YYYY-MM-DD, defaults to today)",
                },
            },
            "required": ["metric"],
        },
    },
]


# ── HTTP Client ────────────────────────────────────────────────────────────────

_client: httpx.AsyncClient | None = None


def get_client() -> httpx.AsyncClient:
    """Get or create the shared httpx async client."""
    global _client
    if _client is None:
        _client = httpx.AsyncClient(
            base_url=CPIS_API_BASE,
            timeout=HTTP_TIMEOUT,
        )
    return _client


async def _api_request(
    method: str,
    path: str,
    json_data: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Make an HTTP request to the CPIS API."""
    client = get_client()
    url = f"{CPIS_API_PREFIX}{path}"
    try:
        response = await client.request(
            method=method,
            url=url,
            json=json_data,
            params=params,
        )
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as exc:
        detail = "unknown error"
        try:
            detail = exc.response.json().get("detail", str(exc))
        except Exception:
            detail = str(exc)
        return {"error": True, "status": exc.response.status_code, "detail": detail}
    except httpx.RequestError as exc:
        return {
            "error": True,
            "status": 0,
            "detail": f"Connection error: {exc}. Is the CPIS backend running at {CPIS_API_BASE}?",
        }


# ── Tool Handlers ──────────────────────────────────────────────────────────────


async def _handle_tool_call(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Route a tool call to the appropriate handler."""

    handlers = {
        "cpis_discover": _handle_discover,
        "cpis_get_candidates": _handle_get_candidates,
        "cpis_select_candidates": _handle_select_candidates,
        "cpis_create_template": _handle_create_template,
        "cpis_run_template": _handle_run_template,
        "cpis_create_schedule": _handle_create_schedule,
        "cpis_query_usage": _handle_query_usage,
    }

    handler = handlers.get(name)
    if handler is None:
        return {
            "content": [
                {
                    "type": "text",
                    "text": f"Unknown tool: {name}",
                }
            ],
            "isError": True,
        }

    try:
        result = await handler(arguments)
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps(result, indent=2, default=str),
                }
            ],
        }
    except Exception as exc:
        return {
            "content": [
                {
                    "type": "text",
                    "text": f"Error executing {name}: {exc}",
                }
            ],
            "isError": True,
        }


async def _handle_discover(args: dict[str, Any]) -> dict[str, Any]:
    """Create a discovery session."""
    body = {
        "query": args["query"],
    }
    if args.get("target_brand"):
        body["target_brand"] = args["target_brand"]
    if args.get("topic"):
        body["topic"] = args["topic"]
    return await _api_request("POST", "/discovery/sessions", json_data=body)


async def _handle_get_candidates(args: dict[str, Any]) -> dict[str, Any]:
    """Get candidates for a discovery session."""
    session_id = args["session_id"]
    params = {
        "page": args.get("page", 1),
        "page_size": min(args.get("page_size", 20), 100),
    }
    return await _api_request(
        "GET",
        f"/discovery/sessions/{session_id}/candidates",
        params=params,
    )


async def _handle_select_candidates(args: dict[str, Any]) -> dict[str, Any]:
    """Batch select or deselect candidates."""
    session_id = args["session_id"]
    body = {
        "candidate_ids": [uuid.UUID(cid) for cid in args["candidate_ids"]],
        "selected": args.get("selected", True),
    }
    # Convert UUIDs to strings for JSON serialization
    body["candidate_ids"] = [str(cid) for cid in body["candidate_ids"]]
    return await _api_request(
        "POST",
        f"/discovery/sessions/{session_id}/select",
        json_data=body,
    )


async def _handle_create_template(args: dict[str, Any]) -> dict[str, Any]:
    """Create a template from session selection."""
    session_id = args["session_id"]
    body = {
        "name": args["name"],
        "description": args.get("description"),
        "feishu_sync_enabled": args.get("feishu_sync_enabled", False),
    }
    return await _api_request(
        "POST",
        f"/discovery/sessions/{session_id}/create-template",
        json_data=body,
    )


async def _handle_run_template(args: dict[str, Any]) -> dict[str, Any]:
    """Execute a template immediately."""
    template_id = args["template_id"]
    return await _api_request(
        "POST",
        f"/collection-templates/{template_id}/run",
    )


async def _handle_create_schedule(args: dict[str, Any]) -> dict[str, Any]:
    """Create a scheduled collection."""
    body: dict[str, Any] = {
        "template_id": args["template_id"],
        "schedule_type": args["schedule_type"],
        "enabled": args.get("enabled", True),
        "max_failures_before_pause": args.get("max_failures_before_pause", 3),
    }
    if args.get("cron_expr"):
        body["cron_expr"] = args["cron_expr"]
    if args.get("interval_minutes"):
        body["interval_minutes"] = args["interval_minutes"]
    return await _api_request(
        "POST",
        "/scheduled-collections",
        json_data=body,
    )


async def _handle_query_usage(args: dict[str, Any]) -> dict[str, Any]:
    """Query usage statistics."""
    metric = args["metric"]
    params: dict[str, Any] = {}
    if args.get("date_from"):
        params["date_from"] = args["date_from"]
    if args.get("date_to"):
        params["date_to"] = args["date_to"]

    if metric == "daily":
        return await _api_request("GET", "/usage/daily", params=params)
    elif metric == "summary":
        return await _api_request("GET", "/usage/summary", params=params)
    else:
        return {"error": True, "detail": f"Unknown metric: {metric}"}


# ── JSON-RPC Handler ──────────────────────────────────────────────────────────


async def _handle_request(request: dict[str, Any]) -> dict[str, Any] | None:
    """
    Handle a single JSON-RPC request.
    Returns None for notifications (no id field).
    """
    req_id = request.get("id")
    method = request.get("method", "")
    params = request.get("params", {})

    # Notifications have no id — skip response
    if req_id is None:
        return None

    try:
        if method == "initialize":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {},
                    },
                    "serverInfo": SERVER_INFO,
                },
            }

        elif method == "notifications/initialized":
            # No response needed for initialization notification
            return None

        elif method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "tools": TOOLS,
                },
            }

        elif method == "tools/call":
            tool_name = params.get("name", "")
            tool_args = params.get("arguments", {})
            result = await _handle_tool_call(tool_name, tool_args)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": result,
            }

        elif method == "ping":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {},
            }

        else:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}",
                },
            }

    except Exception as exc:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {
                "code": -32603,
                "message": f"Internal error: {exc}",
            },
        }


# ── Main Loop ──────────────────────────────────────────────────────────────────


async def _process_stdin() -> None:
    """Read JSON-RPC requests from stdin and write responses to stdout."""
    buffer = ""
    for line in sys.stdin:
        buffer += line
        buffer = buffer.strip()

        if not buffer:
            continue

        # Try to parse as JSON
        try:
            request = json.loads(buffer)
            response = await _handle_request(request)

            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()

            buffer = ""
        except json.JSONDecodeError:
            # Incomplete JSON — read more lines
            continue


async def _process_single_request(request_body: str) -> None:
    """Process a single JSON-RPC request (for one-shot mode)."""
    try:
        request = json.loads(request_body)
        response = await _handle_request(request)
        if response is not None:
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()
    except json.JSONDecodeError as exc:
        sys.stdout.write(
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32700, "message": f"Parse error: {exc}"},
                }
            )
            + "\n"
        )
        sys.stdout.flush()


async def main() -> None:
    """Main entry point for the MCP server."""
    # Detect if we're being piped a single request or running as a daemon
    if not sys.stdin.isatty():
        # stdin is piped — read all input
        raw = sys.stdin.read().strip()
        if raw:
            # Check if this is a newline-delimited JSON stream
            lines = raw.split("\n")
            for line in lines:
                line = line.strip()
                if line:
                    await _process_single_request(line)
            return

    # Interactive/stdin-loop mode (stdio transport)
    await _process_stdin()


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
