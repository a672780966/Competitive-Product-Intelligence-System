# OpenClaw Decoupling Note — CPIS Phase I-Reset

## 1. Background

OpenClaw was previously the primary collection mechanism for CPIS. The
`cpis-json-gate` plugin received data from three OpenClaw agents:
- `cpis-info-collector` (evidence collection)
- `cpis-product-analyst` (product analysis)
- `cpis-knowledge-curator` (Feishu report publishing)

Data flowed: **OpenClaw agents → cpis-json-gate plugin → CPIS bridge endpoint
→ CollectionTask + Product records**.

Phase I-Reset makes the built-in collector (`WhitelistExecutor`) the primary
path, reducing OpenClaw to an optional external data source.

## 2. What STAYS Unchanged

### 2.1 Bridge Endpoint

```
POST /api/v1/openclaw/evidence
```

This external compatibility endpoint is **preserved exactly as-is**. It accepts
the `OpenClawEvidenceRequest` schema and creates `CollectionTask` + `Product` +
`ProductVersion` records. No changes to:
- `app/api/openclaw.py` (route definition)
- `app/services/openclaw_bridge_service.py` (ingestion logic)
- `app/schemas/openclaw.py` (request/response schemas)

### 2.2 cpis-json-gate Plugin

The OpenClaw plugin `cpis-json-gate` (version 1.2.0) continues to work:
- `before_tool_call` hook for evidence validation
- `before_agent_finalize` hook for publish result validation
- Single `POST /evidence` target per OpenClaw run

The plugin source lives outside CPIS at:
```
openclaw-plugins/cpis-json-gate/
```
This is not part of the CPIS codebase and is unaffected by Phase I-Reset.

### 2.3 Agent Rules

The three agent rule files remain valid for users who still use OpenClaw:
```
openclaw-agents-v2/
├── collector-rules.md
├── analyst-rules.md
├── curator-rules.md
├── IMAGE-WORKFLOW.md
```

These are documentation/configuration files managed separately from CPIS code.

### 2.4 Existing Data Model

No existing database tables are altered. The `openclaw_ingest` task stage in
`TaskEvent` values remains valid. Bridge-created tasks continue to appear
in task listings alongside built-in tasks.

## 3. What CHANGES

### 3.1 OpenClaw Is No Longer the Primary Collector

**Before Phase I-Reset:**
```
User/agent → OpenClaw agents → cpis-json-gate → Bridge → CPIS data model
```
The pipeline depended on OpenClaw for all collection.

**After Phase I-Reset:**
```
User/agent ─┬─ Discovery API → Built-in Collector → CPIS data model  ★ PRIMARY
             └─ OpenClaw → Bridge → CPIS data model                    ★ OPTIONAL
```

The primary path is now:
1. `POST /api/v1/discovery/sessions` (user provides URL or search query)
2. Built-in `WhitelistExecutor` fetches content
3. Content is cleaned and candidates extracted
4. User promotes candidates to `CollectionTask`
5. Existing pipeline (clean → extract → version → review → sync) proceeds

OpenClaw becomes an **optional data source** for organizations that already
have OpenClaw deployed and want to keep using their agent configurations.

### 3.2 cpis-* Agents Are Optional

The three OpenClaw agents (`cpis-info-collector`, `cpis-product-analyst`,
`cpis-knowledge-curator`) are no longer required for CPIS operation.

Users who want a fully self-contained system can:
- Skip OpenClaw entirely
- Use the new discovery + collection template system
- Use the built-in collector for all web fetching
- Use the existing Feishu sync service (unchanged) for publishing

Users who have invested in OpenClaw agent configurations can:
- Keep OpenClaw running alongside the new system
- Still use `POST /api/v1/openclaw/evidence` to ingest agent results
- Use the new discovery system as a complement for ad-hoc collection

### 3.3 RunPlan Replaces Agent Logic

OpenClaw agents could encode arbitrary collection logic in their system
prompts (e.g., "go to page X, click button Y, extract field Z"). This
dynamic code execution is **not allowed** in the new RunPlan-based approach.

The new system uses **declarative JSON-only RunPlans** (see
`RUNPLAN_DECLARATIVE_SPEC.md`). A RunPlan describes what to collect (URLs,
sources) but not how to collect it — the `WhitelistExecutor` determines the
execution strategy based on allowed collector kinds.

## 4. Migration Path from OpenClaw to Built-In

For teams that want to migrate away from OpenClaw:

### Phase 1: Side-by-Side (Immediate)

```
Run both systems concurrently:
- OpenClaw continues ingesting via bridge
- New discovery system is used for new collection tasks
- All data lands in the same CPIS database
```

**Steps:**
1. Deploy Phase I-Reset code (no changes to existing data)
2. Start using `POST /api/v1/discovery/sessions` for new discovery needs
3. Create collection templates for recurring collection patterns
4. OpenClaw bridge continues to work for existing agent workflows

### Phase 2: Transition (1-2 weeks)

```
Gradually reduce OpenClaw dependency:
- Recreate important OpenClaw collection patterns as declarative RunPlans
- Set up scheduled collections to replace recurring agent tasks
- Validate that built-in collector quality matches OpenClaw results
```

**Steps:**
1. For each OpenClaw run that collects product pages:
   - Identify the source URLs the agent was configured to collect
   - Create a `CollectionTemplate` with those URLs in the RunPlan
   - Test that the built-in collector produces equivalent results
2. For OpenClaw runs that do web search → collect:
   - Use the new discovery search path
   - The `SearchProvider` interface supports DuckDuckGo/Bing/SerpAPI
3. Compare data quality: built-in extraction vs OpenClaw agent output

### Phase 3: OpenClaw Optional (1 month+)

```
OpenClaw can be fully decommissioned if desired:
- All collection is handled by the built-in system
- All scheduling is handled by Celery Beat
- All data flows through standard CPIS pipeline
```

**Steps:**
1. Disable OpenClaw agents one by one
2. Remove OpenClaw gateway dependency (if no longer needed for other purposes)
3. Optionally remove the bridge endpoint (retain for backward compatibility)

## 5. Feature Comparison: OpenClaw vs Built-In

| Capability | OpenClaw | Built-In |
|-----------|----------|----------|
| Static URL fetch | ✅ Via tools | ✅ direct_http |
| JS-rendered pages | ✅ Via tools | ✅ playwright |
| Advanced scraping (SPAs) | ✅ Via agent logic | 🟡 scrapling/crawl4ai (feature gated) |
| Custom extraction logic | ✅ Full agent prompts | ❌ RunPlan is declarative only |
| Web search → collect | ✅ Via tools | ✅ SearchProvider interface |
| Scheduled collection | ❌ Manual per-run | ✅ Celery Beat |
| Usage tracking | ❌ Not tracked | ✅ UsageDailyStat |
| Template reuse | ❌ Per-run config | ✅ CollectionTemplate |
| Agent skills/MCP | ❌ External | ✅ Built-in skills + MCP tools |
| Feishu sync | ✅ Agent publishes directly | ✅ Service-based (unchanged) |
| Data quality validation | ✅ cpis-json-gate plugin | ✅ Schema validation + tests |

## 6. Summary of Changes

| Component | Status | Detail |
|-----------|--------|--------|
| `POST /api/v1/openclaw/evidence` | ✅ PRESERVED | No changes |
| `app/api/openclaw.py` | ✅ UNCHANGED | No edits |
| `app/services/openclaw_bridge_service.py` | ✅ UNCHANGED | No edits |
| `app/schemas/openclaw.py` | ✅ UNCHANGED | No edits |
| `cpis-json-gate` plugin | ✅ UNCHANGED | External to CPIS |
| `cpis-*` agent rules | ✅ UNCHANGED | External to CPIS |
| Primary collection path | 🔄 CHANGED | OpenClaw → Built-in WhitelistExecutor |
| Collection logic | 🔄 CHANGED | Agent prompts → Declarative RunPlan |
| cpis-* agents requirement | 🔄 CHANGED | Required → Optional |
| RunPlan | 🆕 NEW | Declarative JSON only, no dynamic code |
| Discovery API | 🆕 NEW | `POST /api/v1/discovery/sessions` |
| Collection templates | 🆕 NEW | Reusable declarative configs |
| Celery Beat scheduling | 🆕 NEW | Cron-based periodic collection |
| Usage stats | 🆕 NEW | Aggregated collection metrics |

## 7. Compatibility Guarantee

All existing OpenClaw data in the CPIS database remains fully accessible.
Bridge-created `CollectionTask`, `Product`, and `ProductVersion` records
work identically with all existing frontend pages (tasks, products, reviews,
sync, reports), and all existing API endpoints retrieve them correctly.

The bridge endpoint will remain supported for at least 6 months after
Phase I-Reset deployment, with no planned deprecation date.
