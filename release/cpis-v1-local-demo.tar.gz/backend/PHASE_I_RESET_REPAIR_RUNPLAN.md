# PHASE I RESET — RunPlan Format Fix

## Summary

Fixed the `RunPlan` format mismatch that caused `POST /api/v1/collection-templates/{id}/run` to return 500 with `"version/sources required" ValidationError`.

## Root Cause

The `discovery_service.py` `create_template_from_selection` method was generating `run_plan` in an old format:

```json
{"collectors": ["direct_http"], "collection_scope": [...]}
```

But `RunPlanSchema` (in `schemas/run_plan.py`) expects:

```json
{"version": "1.0", "sources": [...], "collector": {...}, "scope": {...}}
```

When `template_service.py` `run_template` tried to use the stored `run_plan`, it passed the old-format dict through `validate_run_plan()`, which failed with validation errors because the required `version` and `sources` fields were missing.

## Changes Made

### 1. `app/services/discovery_service.py` (Root Cause Fix)

**Before** (lines 282-293):
```python
run_plan = {
    "collectors": ["direct_http"],
    "collection_scope": [
        {
            "url": c.url,
            "collector": c.recommended_collector.value
            if hasattr(c.recommended_collector, "value")
            else c.recommended_collector,
        }
        for c in selected
    ],
}
```

**After**:
```python
run_plan = {
    "version": "1.0",
    "name": req.name,
    "sources": [
        {
            "type": "url_list",
            "urls": [c.url for c in selected],
            "category_hint": session.topic,
        },
    ],
    "collector": {
        "kind": "direct_http",
        "params": {},
    },
    "scope": {
        "max_pages": 50,
        "max_pages_per_domain": 25,
        "respect_robots_txt": True,
        "delay_between_requests_ms": 500,
    },
}
```

This ensures all newly created templates have a `RunPlanSchema`-compliant `run_plan`.

### 2. `app/services/template_service.py` (Safety Net)

**Before** (line 138):
```python
plan_data = template.run_plan or self._build_plan_from_source_plan(template)
```

**After**:
```python
plan_data = template.run_plan
if plan_data:
    try:
        validate_run_plan(plan_data)
    except Exception:
        logger.warning(
            "run_plan_validation_failed_falling_back_to_source_plan",
            template_id=str(template_id),
        )
        plan_data = self._build_plan_from_source_plan(template)
else:
    plan_data = self._build_plan_from_source_plan(template)
```

This adds a safety net: if the stored `run_plan` fails validation (old format), it falls back to building a correct `RunPlan` from the `source_plan` data. The `_build_plan_from_source_plan` method already generated valid `RunPlanSchema` format — it just wasn't being reached when `run_plan` was a truthy dict.

## Verification

| Test | Result |
|------|--------|
| `GET /api/v1/collection-templates/{id}` (old template) | run_plan shows legacy format but endpoint still works |
| `POST /api/v1/collection-templates/{id}/run` (old template) | ✅ Returns `{"tasks_created": 4, ...}` via fallback path |
| `GET /api/v1/collection-templates/{id}` (new template) | ✅ run_plan shows proper RunPlanSchema format |
| `POST /api/v1/collection-templates/{id}/run` (new template) | ✅ Returns `{"tasks_created": 8, ...}` via direct path |
| `pytest` (full suite) | ✅ **439 passed** (same as baseline before reset) |

## Files Modified

- `backend/app/services/discovery_service.py` — fixed `run_plan` format in `create_template_from_selection`
- `backend/app/services/template_service.py` — added validation + fallback in `run_template`
- `backend/PHASE_I_RESET_REPAIR_RUNPLAN.md` — this file

## Architecture

```
discovery_service.py ──create_template_from_selection──▶ CollectionTemplate
                                                           ├── source_plan (rich data)
                                                           └── run_plan (executable RunPlanSchema format)
                                                                │
template_service.py ──run_template──────────────────────────────┤
    ├── Validate run_plan against RunPlanSchema                  │
    ├── If valid: use it directly                                │
    └── If invalid: build from source_plan (fallback)            │
                                                                 ▼
collection_runner_service.py ──execute_plan──▶ validate_run_plan() → create CollectionTasks
```
