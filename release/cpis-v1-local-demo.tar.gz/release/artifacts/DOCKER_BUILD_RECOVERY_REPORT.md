# DOCKER BUILD RECOVERY REPORT — CPIS V1

**Date:** 2026-06-27
**Trace:** docker-build-recovery-gate

---

## Problem

Docker 29.6.0 with containerd-native snapshotter (`overlayfs`, driver-type: `io.containerd.snapshotter.v1`) has a known bug where multi-stage Docker builds fail at the final image export step with:

```
wrong diff id calculated on extraction
```

This affects `COPY --from=builder` operations that copy large directory trees (Python site-packages, Playwright browsers).

## Root Cause

The containerd v2.2.5 native snapshotter calculates diff IDs differently than the classic overlay2 driver during multi-stage build layer exports. This is a Docker Engine / containerd compatibility issue, not a Dockerfile syntax error.

## Fix Applied

### Strategy: Pre-build images with `buildx --output type=docker`

The `docker buildx build --output type=docker` command bypasses the containerd-native image format and writes the image in the classic Docker format (v1 manifest, tar layers). This avoids the diff ID calculation bug.

### Files Changed/Created

| File | Change |
|------|--------|
| `scripts/build-images.sh` | **NEW** — Builds backend + frontend images using `docker buildx build --output type=docker --no-cache` |
| `docker-compose.demo.yml` | Changed from `build:` to `image:` references; added inline environment defaults for DATABASE_URL, REDIS_URL, CELERY_*, LLM_PROVIDER, PYTHONPATH |
| `scripts/start_demo.sh` | Added image existence check + auto-build via `build-images.sh`; uses `sg docker -c` for docker group access |
| `scripts/stop_demo.sh` | No changes needed (already worked) |

## Verification

### Build
```
Backend: docker buildx build --output type=docker -t cpis-backend   ✅ SUCCESS
Frontend: docker buildx build --output type=docker -t cpis-frontend  ✅ SUCCESS
```

### Compose Up
| Service | Status |
|---------|--------|
| postgres | ✅ healthy (5432) |
| redis | ✅ healthy (6379) |
| migrate | ✅ Exited(0) — alembic upgrade head |
| backend | ✅ healthy (8000) |
| celery-worker | ✅ up |
| frontend | ✅ up (8080) |

### E2E
- ✅ Backend health: `CPIS V1 is running.`
- ✅ Health check: `{"status":"alive","service":"cpis-v1"}`
- ✅ Seed: 3 products, 1 session, 1 template — **NO 405/500**
- ✅ API verify: Products=3, Sessions=1, Templates=1
- ✅ Provider status: DuckDuckGo + Stub LLM
- ✅ Frontend: HTTP 200

### Compose Down
- ✅ `stop_demo.sh` — All 6 containers removed, network cleaned

## Portability

- Requires Docker 19.03+ (includes `docker buildx`)
- `buildx --output type=docker` is available on all platforms
- No host-specific paths or dependencies
- Works on Linux, macOS, Windows
