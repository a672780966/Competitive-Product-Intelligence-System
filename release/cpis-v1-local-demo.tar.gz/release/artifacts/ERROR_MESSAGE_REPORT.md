# ERROR MESSAGE REPORT — CPIS V1 Error Handling Audit

**Date:** 2026-06-27
**Trace:** product-usability-hardening-v1

---

## Overall Score: 5.2/10

Error handling is inconsistent — `failure_intelligence.py` uses Chinese with actionable suggestions, but API routes and schema validation all return English error messages.

## Per-Error-Path Assessment

### 1. DNS Failures
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | 🟡 Partial |
| Language | **Chinese** in failure_intelligence.py, **English** in url_validator.py |
| Actionable? | 🟡 Shows URL + error, but not always suggests checking internet/DNS |
| **Verdict** | Good in collector, weak in validator |

### 2. HTTP 403
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | ✅ Good |
| Language | **Chinese** |
| Actionable? | ✅ Suggests user-agent rotation, retry limits |
| **Verdict** | ✅ Best in codebase |

### 3. JS Challenge Detection (Cloudflare/WAF)
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | ❌ **Completely missing** |
| **Verdict** | 🔴 **No detection exists** — Cloudflare/WAF pages are returned as raw HTML, no user is told "this page is behind a JS challenge" |

### 4. Blocked Sources (LOGIN/ROBOTS/CAPTCHA)
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | 🟡 Partial |
| Language | Chinese in failure_intelligence, English in url_validator |
| Actionable? | 🟡 Could be more specific |
| **Verdict** | Needs unification to Chinese |

### 5. Missing Providers (SEARCH/LLM)
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | ✅ Acceptable — system gracefully falls back to mock/stub |
| Language | English |
| Actionable? | 🟡 Should tell user what env vars to set |
| **Verdict** | Graceful degradation works, but messages not user-friendly |

### 6. Feishu Missing
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | ✅ Good — graceful degradation |
| Language | English |
| Actionable? | ✅ Logs warning with env var name |
| **Verdict** | ✅ Works, should add Chinese version |

### 7. API Routes (11 routers)
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | ❌ **All English** |
| Language | English ❌ |
| **Verdict** | 🔴 15+ error messages need localization |

### 8. Global Exception Handlers
| Criterion | Assessment |
|-----------|-----------|
| Human-readable? | 🟡 Partial — FastAPI default 422 exposes raw validation errors |
| Language | English |
| **Verdict** | Needs custom 422 handler in Chinese |

---

## Priority Recommendations

### P0 — Must Fix
1. **JS Challenge detection**: Add Cloudflare/WAF/PerimeterX detection
2. **API error messages**: Localize all 15+ error messages to Chinese
3. **422 validation handler**: Add custom Chinese handler

### P1 — Should Fix
4. URL validator messages to Chinese
5. Provider missing — show specific env var names
6. Global exception handler — wrap all unhandled exceptions

### P2 — Nice to Have
7. Feishu missing — Chinese warning
8. Search history error — add Chinese message

---

## Verdict

The system works correctly from a technical standpoint (no crashes, graceful degradation works), but user-facing error messages are predominantly English with inconsistent quality. For a **中文用户** (Chinese user) target audience, error messages should be fully localized to Chinese.
