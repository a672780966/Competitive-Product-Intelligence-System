# CPIS V1 Local Demo — Artifact Unpack Smoke Report

**Date:** 2026-06-27  
**Artifact:** `release-artifacts/cpis-v1-local-demo.tar.gz` (829,365 bytes)  
**SHA256:** `a74e95c7c291c336d20f05c05233d8e79afcd0d4fc4bb6694fc2cb833c46c2c6`  
**Inspection method:** Python tarfile extraction, file-level diff against current codebase (`main` branch)

---

## 1. Archive Integrity

| Check | Result | Details |
|-------|--------|---------|
| Archive exists | ✅ PASS | `/home/ctyun/Competitive-Product-Intelligence-System/release-artifacts/cpis-v1-local-demo.tar.gz` |
| Gzip readable | ✅ PASS | 322 members (279 files, 43 directories) |
| No truncation/corruption | ✅ PASS | All members read successfully |
| Total unpacked size | ✅ PASS | 3,041 KB |

---

## 2. File Completeness

### Requested critical files

| File | Status | Size |
|------|--------|------|
| `release/QUICK_START.md` | ✅ Present | 3,390 bytes |
| `docker-compose.demo.yml` | ✅ Present | 1,578 bytes |
| `.env.example` | ❌ **MISSING** | — |
| `scripts/start_demo.sh` | ✅ Present | 585 bytes |
| `scripts/stop_demo.sh` | ✅ Present | 205 bytes |
| `backend/Dockerfile` | ✅ Present | 1,965 bytes |
| `frontend/Dockerfile` | ✅ Present | 283 bytes |
| `backend/app/` (directory) | ✅ Present | 129 entries (all modules) |

### Other notable files found

- `README.md` ✅
- `docker-compose.yml` ✅
- `release/RELEASE_NOTES.md` ✅
- `release/CHANGELOG.md` ✅
- `release/LICENSE.md` ✅
- `release/DEMO_SCRIPT.md` ✅
- `release/DEPLOYMENT_GUIDE.md` ✅
- `backend/pyproject.toml` ✅
- `backend/poetry.lock` ✅
- `backend/alembic.ini` ✅
- `frontend/package.json` ✅
- `frontend/nginx.conf` ✅
- `frontend/dist/` (prebuilt frontend) ✅

### Critical gap

**`.env.example` is MISSING from the release artifact.** This file is required by:
- **QUICK_START.md** step 2: instructs user to `cp .env.example .env`
- **start_demo.sh** (current version): auto-creates `.env` from `.env.example` if missing

Without `.env.example`, a first-time user following QUICK_START.md would get an error on the `cp .env.example .env` command. This is a **blocking issue** for the demo experience.

---

## 3. Version Consistency: Archive vs Current Codebase

The archive was built from an **older revision** of the codebase. Four files in the archive are outdated relative to the current working tree:

### 3.1 `docker-compose.demo.yml` — Outdated

| Aspect | Archive (old) | Current codebase |
|--------|---------------|------------------|
| `version:` field | Has `version: "3.9"` | Removed (deprecated in Compose v2) |
| `migrate` service | **Missing** | Present — runs `alembic upgrade head` on startup |
| Dependency chains on backend/celery-worker | **Missing** | Present — wait for `migrate` + `postgres` + `redis` health |

**Impact:** With the archive version, schema migrations are not automatically applied. The backend may fail to start against a fresh database.

### 3.2 `scripts/start_demo.sh` — Outdated

| Aspect | Archive (old) | Current codebase |
|--------|---------------|------------------|
| `.env` auto-creation | **Missing** | Present — detects missing `.env` and copies from `.env.example` |
| Health check loop | Simple `until` loop (no timeout) | For-loop with 60s timeout and clear error message |
| Seed error suppression | `2>/dev/null \|\| true` (silent) | No suppression (fail visible) |

**Impact:** User may get stuck waiting if backend never starts (no timeout), and missing `.env` auto-creation makes setup more manual.

### 3.3 `scripts/stop_demo.sh` — Outdated

| Aspect | Archive (old) | Current codebase |
|--------|---------------|------------------|
| `--remove-orphans` flag | **Missing** | Present |
| Reset instructions | **Missing** | Present — hints about `-v` flag for data reset |

**Impact:** Orphan containers may be left behind after stop.

### 3.4 `backend/Dockerfile` — Outdated

| Aspect | Archive (old) | Current codebase |
|--------|---------------|------------------|
| `docker-entrypoint.sh` | **Missing** | Present — copied and made executable |
| `ENTRYPOINT` directive | **Missing** | Present — `/app/docker-entrypoint.sh` |

**Impact:** Without the entrypoint, the container may not run startup logic (e.g., waiting for DB, running pre-flight checks).

### Files that are identical (archive == current)

| File | Match |
|------|-------|
| `release/QUICK_START.md` | ✅ Identical |
| `frontend/Dockerfile` | ✅ Identical |
| `README.md` | ✅ Identical |
| `.env` (not in archive, exists in codebase only) | N/A |

---

## 4. QUICK_START.md Instruction Verification

The QUICK_START.md in the archive was compared against the actual files in the current codebase. **Three mismatches** were found:

### Mismatch 1 — Frontend port (HIGH severity)

| Source | Port | Detail |
|--------|------|--------|
| **QUICK_START.md** | **5173** | "React frontend — web UI (port 5173)" / "Open http://localhost:5173" |
| **docker-compose.demo.yml** | **8080** | `"8080:80"` (maps host port 8080 → nginx container port 80) |
| **start_demo.sh** | **8080** | "Frontend: http://localhost:8080" |

**Action needed:** Update QUICK_START.md to say port **8080** to match the demo compose file.

### Mismatch 2 — Docker compose file reference (MEDIUM severity)

| Source | Command |
|--------|---------|
| **QUICK_START.md** | `docker compose up -d` (uses default `docker-compose.yml`) |
| **start_demo.sh** | `docker compose -f docker-compose.demo.yml up -d` (uses demo override) |

The QUICK_START.md instructs users to use the standard compose file, but the demo is designed to be launched with `docker-compose.demo.yml`. The default compose file may not have all services configured for the demo scenario.

### Mismatch 3 — Seed command path (LOW severity)

| Source | Seed command |
|--------|-------------|
| **QUICK_START.md** | `docker compose exec backend python scripts/seed_demo.py` |
| **start_demo.sh** | `docker compose -f docker-compose.demo.yml exec -T backend python /app/scripts/seed_demo.py` |

The QUICK_START uses a relative path (`scripts/seed_demo.py`) while the actual script uses an absolute container path (`/app/scripts/seed_demo.py`). Both resolve to the same file in practice (WORKDIR is `/app`), but the inconsistency could confuse users.

### Mismatch 4 — Missing convenience scripts reference (LOW severity)

QUICK_START.md does not mention `scripts/start_demo.sh` or `scripts/stop_demo.sh` as alternatives to `docker compose up -d` / `docker compose down`. Users are not aware of the one-command demo experience.

---

## 5. Overall Verdict

| Category | Verdict |
|----------|---------|
| Archive integrity | ✅ PASS — not corrupt, valid gzip tar |
| File completeness | ⚠️ **PARTIAL FAIL** — `.env.example` is missing; all other critical files present |
| Version freshness | ⚠️ **STALE** — 4 files (docker-compose.demo.yml, start_demo.sh, stop_demo.sh, backend/Dockerfile) are outdated vs current codebase |
| Instruction accuracy | ⚠️ **MISMATCHES** — Frontend port is wrong (5173 vs 8080), compose file reference differs |

### Blocking issues (must fix before release)

1. **Missing `.env.example`** — Add this file to the archive. Without it, `cp .env.example .env` (step 2 in QUICK_START) fails.
2. **Frontend port mismatch** — QUICK_START.md says port 5173, but the demo compose file uses port 8080. Fix QUICK_START.md to say 8080.

### Recommended fixes

1. Rebuild the archive from the current codebase (all 4 stale files would be updated).
2. Add `.env.example` to the archive by including it in the packaging script (`scripts/package-release.sh`).
3. Revise QUICK_START.md to either:
   - Reference `scripts/start_demo.sh` as the primary entry point, OR
   - Fix the port to 8080 and reference `-f docker-compose.demo.yml` if manual startup is preferred.
4. Add `scripts/start_demo.sh` and `scripts/stop_demo.sh` to the list of convenience commands in QUICK_START.md.
