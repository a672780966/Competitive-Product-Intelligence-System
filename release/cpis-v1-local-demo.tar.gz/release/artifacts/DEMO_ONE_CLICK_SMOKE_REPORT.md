# DEMO ONE-CLICK SMOKE REPORT — CPIS V1

**Date:** 2026-06-27
**Trace:** product-usability-hardening-v1

---

## One-Click Start Verification

### Command
```bash
cd /home/ctyun/Competitive-Product-Intelligence-System
bash scripts/start_demo.sh
```

### Auto-Features
| Feature | Status |
|---------|--------|
| Auto-create `.env` from `.env.example` | ✅ If .env missing |
| Auto-build Docker images (buildx) | ✅ If images missing |
| Docker compose up | ✅ All 6 services |
| Alembic migration auto-run | ✅ Via migrate service |
| Health check (60s timeout) | ✅ With diagnostic message |
| Demo data seed | ✅ 3 products, 1 session, 1 template |
| Post-seed verification | ✅ Confirms data in DB |

### One-Command Stop
```bash
bash scripts/stop_demo.sh
```

## Container Status After Start

```
NAME                                    IMAGE               STATUS              PORTS
postgres-1                              postgres:16-alpine  Up (healthy)        0.0.0.0:5432
redis-1                                 redis:7-alpine      Up (healthy)        6379
migrate-1                               cpis-backend        Exited (0)          —
backend-1                               cpis-backend        Up (healthy)        0.0.0.0:8000
celery-worker-1                         cpis-backend        Up                  8000
frontend-1                              cpis-frontend       Up                  0.0.0.0:8080
```

## Acceptance Criteria

| # | Criterion | Result |
|---|-----------|--------|
| 1 | Backend health | ✅ `CPIS V1 is running.` |
| 2 | Frontend accessible (port 8080) | ✅ **HTTP 200** |
| 3 | PostgreSQL healthy | ✅ container healthy |
| 4 | Redis healthy | ✅ container healthy |
| 5 | Celery worker running | ✅ container up |
| 6 | Alembic auto-migrated | ✅ migrate Exited(0) |
| 7 | seed_demo.py no 405/500 | ✅ 3 products, 1 session, 1 template |
| 8 | Discovery session created | ✅ 1 session verified |
| 9 | Template created | ✅ 1 template verified |
| 10 | Provider status readable | ✅ DuckDuckGo + Stub LLM |
| 11 | stop_demo.sh clean stop | ✅ All containers + network removed |

## Verdict

**ONE-CLICK DEMO: ✅ PASSED**

A new user can execute exactly 3 commands:
```bash
git clone <repo>
cd Competitive-Product-Intelligence-System
bash scripts/start_demo.sh
```
And have a fully functional CPIS V1 system in under 5 minutes.
