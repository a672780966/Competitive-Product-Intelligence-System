# CPIS V1 — 错误信息用户友好性审计报告

> 审计时间：2026-06-27
> 审计范围：CPIS V1 后端所有错误路径
> 审计人：Hermes Agent

---

## 目录

1. [审计方法与范围](#1-审计方法与范围)
2. [错误路径逐项评估](#2-错误路径逐项评估)
   - [2.1 DNS 解析失败（URL 收集）](#21-dns-解析失败url-收集)
   - [2.2 HTTP 403 禁止访问（URL 收集）](#22-http-403-禁止访问url-收集)
   - [2.3 JS 质询检测（Cloudflare 等 WAF）](#23-js-质询检测cloudflare-等-waf)
   - [2.4 来源被屏蔽（LOGIN_REQUIRED / ROBOTS_TXT_BLOCKED 等）](#24-来源被屏蔽login_required--robots_txt_blocked-等)
   - [2.5 提供商缺失（SEARCH_PROVIDER / LLM_PROVIDER 未配置）](#25-提供商缺失search_provider--llm_provider-未配置)
   - [2.6 飞书未配置（FEISHU_APP_ID 缺失）](#26-飞书未配置feishu_app_id-缺失)
   - [2.7 API 路由通用错误处理](#27-api-路由通用错误处理)
   - [2.8 采集管道通用异常](#28-采集管道通用异常)
3. [总体评估表](#3-总体评估表)
4. [具体修复建议](#4-具体修复建议)
5. [总体结论](#5-总体结论)

---

## 1. 审计方法与范围

### 审计方法
- 逐一阅读源代码文件
- 检查每条错误路径的：错误消息语言（中文/英文）、是否可理解、是否提供解决建议、是否有优雅降级路径
- 标记问题等级：🔴 严重 / 🟡 中等 / 🟢 良好

### 审计文件清单

| # | 文件路径 | 核心功能 |
|---|---------|---------|
| 1 | `backend/app/collectors/failure_intelligence.py` | 失败智能分析引擎 |
| 2 | `backend/app/collectors/direct_http.py` | HTTP 采集器（含重试、UA 轮换、Failure Intel 集成） |
| 3 | `backend/app/services/url_validator.py` | URL 合规校验（SSRF、robots.txt、登录页检测） |
| 4 | `backend/app/core/exceptions.py` | 全局异常处理器 |
| 5 | `backend/app/integrations/feishu_client.py` | 飞书 API 客户端 |
| 6 | `backend/app/services/feishu_sync_service.py` | 飞书同步服务 |
| 7 | `backend/app/services/task_service.py` | 任务服务（含 URL 验证编排） |
| 8 | `backend/app/tasks/collection.py` | Celery 采集任务（收集/清洗/提取） |
| 9 | `backend/app/api/*.py`（11 个路由文件） | 所有 API 路由 |
| 10 | `backend/app/schemas/__init__.py` | URL 验证错误码定义 |
| 11 | `backend/app/providers/config.py` | 提供商配置 |
| 12 | `backend/app/collectors/selector.py` | 采集器选择器 |

---

## 2. 错误路径逐项评估

### 2.1 DNS 解析失败（URL 收集）

**涉及文件：** `failure_intelligence.py`, `direct_http.py`, `url_validator.py`

#### 当前实现

**`failure_intelligence.py` L27-32：**
```python
"DNS_FAILURE": {
    "failure_type": "dns_failure",
    "retryable": False,
    "suggested_next": "search_alternative",
    "user_visible_message": "域名解析失败，网站可能已关闭或域名已过期",
}
```

检测关键词：`name or service not known`、`nodename nor servname`、`getaddrinfo`、`temporary failure in name resolution`

**`direct_http.py` L322-336：**
发生 `httpx.ConnectError` 且含 DNS 关键词时返回：
- `error_code = "DNS_FAILURE"`
- `error_message = f"Connection error: {last_exception}"` → 原始异常英文
- 但通过 `_make_failure_result()` 调用 `analyze_failure()` 生成 `FailureAnalysis.user_visible_message`（中文）

**`url_validator.py` L106-108：**
DNS 解析失败时返回：
- `error_message = "DNS resolution or connection failed"` → 英文

#### 评估结果 🟡

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟡 混合 | failure_intelligence 中文 ✅；url_validator 英文 ❌ |
| 可理解性 | 🟡 良好但混杂 | 中文消息好，但 raw error 暴露了底层技术细节 |
| 解决建议 | 🟢 良好 | `suggested_next: "search_alternative"` 有指导意义 |
| 优雅降级 | 🟢 良好 | 有重试机制且标记为不可重试 |

---

### 2.2 HTTP 403 禁止访问（URL 收集）

**涉及文件：** `failure_intelligence.py`, `direct_http.py`, `url_validator.py`

#### 当前实现

**`failure_intelligence.py` L33-38：**
```python
"HTTP_403": {
    "failure_type": "http_error",
    "retryable": True,
    "suggested_next": "retry_ua_rotate",
    "user_visible_message": "服务器返回403禁止访问，尝试更换User-Agent或使用浏览器渲染",
}
```

**`direct_http.py` L349-365：** HTTP ≥ 400 时调用 `analyze_failure(http_status=403)` 正确映射。

**`url_validator.py` L112-115：** 返回 `f"HTTP {head_result['status_code']}"` — 通用无区分。

#### 评估结果 🟢（failure_intelligence）/ 🟡（url_validator）

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟢 | Chinese ✅「尝试更换User-Agent或使用浏览器渲染」|
| 可理解性 | 🟢 | 清晰说明问题 + 原因 + 解决方法 |
| 解决建议 | 🟢 | `retry_ua_rotate` 具体可执行 |
| url_validator | 🟡 | 所有 ≥400 状态码统一「HTTP {code}」，无区分无建议 |

---

### 2.3 JS 质询检测（Cloudflare 等 WAF）

**涉及文件：** `failure_intelligence.py`, `url_validator.py`

#### 当前实现

**`failure_intelligence.py`：** ❌ **没有专门的 JS 挑战/Cloudflare 检测类别。**
- `BLOCKED_SOURCE` 类别（L75-80）泛化描述「该来源已被安全策略拦截」，未提及 JS 渲染。
- 没有 `__cf_chl_opt`、`cf-wrapper`、`/_cfs/` 等 Cloudflare 关键特征检测。

**`url_validator.py` L62-64：** CAPTCHA 关键词检测仅覆盖：
```
(captcha|recaptcha|hcaptcha|verify\s*you.*human|验证码|人机验证)
```
**未覆盖 Cloudflare 特征。**

**`url_validator.py` L65-67：** Access denied 关键词：
```
(access\s*denied|403\s*forbidden|blocked|拒绝访问|禁止访问|forbidden)
```
可部分捕获但无法区分 JS 质询场景。

#### 评估结果 🔴

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟡 | 部分英文检测词 |
| 可理解性 | 🔴 | **没有专门的 JS 挑战识别**，用户不知道需要浏览器渲染 |
| 解决建议 | 🔴 | 无建议尝试 Playwright/Scrapling |
| 优雅降级 | 🟡 | `_should_use_playwright()` 在 `selector.py` 中对 403/503 会尝试 Playwright，但无显式 WAF 检测 |

---

### 2.4 来源被屏蔽（LOGIN_REQUIRED / ROBOTS_TXT_BLOCKED 等）

**涉及文件：** `failure_intelligence.py`, `url_validator.py`, `selector.py`, `task_service.py`

#### 当前实现

**分类对比表：**

| 屏蔽类型 | failure_intelligence 处理 | url_validator 处理 | 语言 |
|---------|------------------------|-------------------|------|
| ROBOTS_TXT_BLOCKED | ❌ 无独立类别（BLOCKED_SOURCE 泛化） | ✅ `_check_robots_txt()` 返回 `f"Blocked by robots.txt: {robots_url}"` | 英文 |
| LOGIN_REQUIRED | ❌ 无独立类别 | ✅ L59-61 检测，返回 "Login page detected (requires authentication)" | 英文 |
| CAPTCHA_DETECTED | ❌ 无独立类别 | ✅ L62-64 检测，返回 "CAPTCHA detected (automated access blocked)" | 英文 |
| 访问被拒 | ✅ BLOCKED_SOURCE：「该来源已被安全策略拦截」| ✅ L138，返回 "Access denied / forbidden page detected" | 中/英混合 |

**`selector.py` L70-75：** 当 risk_level="blocked" 时返回英文提示 `"Source risk level is 'blocked' — no collector allowed"`。

**`task_service.py` L272-285：** 验证失败时 error_message 透传 url_validator 返回的原始英文消息。

#### 评估结果 🟡

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟡 混杂 | failure_intelligence 中文；url_validator 全英文；selector 英文 |
| 可理解性 | 🟡 | 英文消息对国内用户不够友好 |
| 解决建议 | 🔴 | 仅 failure_intelligence 有 `suggested_next`；url_validator 无任何解决建议 |
| 分类覆盖 | 🟡 | failure_intelligence 的 BLOCKED_SOURCE 过于泛化，未区分具体屏蔽原因 |

---

### 2.5 提供商缺失（SEARCH_PROVIDER / LLM_PROVIDER 未配置）

**涉及文件：** `core/__init__.py` (Settings), `providers/config.py`, `api/provider_status.py`

#### 当前实现

**Settings 默认值（`core/__init__.py`）：**
```python
LLM_PROVIDER: str = "openai_compatible"
SEARCH_PROVIDER: str = "mock"
FEISHU_APP_ID: str = ""  # 默认空
```

- **没有启动时验证** — 系统在 mock/stub 模式下静默运行
- **`provider_status.py` L33-40**：仅当 LLM provider 非 mock/stub 时才检查 API key 缺失
- **提供商层不会报错** — 所有实际 API 调用通过抽象层，不配置就直接使用 mock

#### 评估结果 🟡

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟡 | provider_status API 返回英文字段 |
| 可理解性 | 🔴 | **无启动验证**，用户可能在无搜索/无 LLM 状态下运行却不知情 |
| 解决建议 | 🔴 | 无任何提示告知用户需要配置哪些环境变量 |
| 优雅降级 | 🟢 | 巧妙使用 mock/stub 兜底，但隐藏了配置缺失的事实 |

**具体缺失：** 应增加启动验证，在 APP 启动时检查关键提供商配置，若缺失则打印清晰地中文提示。

---

### 2.6 飞书未配置（FEISHU_APP_ID 缺失）

**涉及文件：** `integrations/feishu_client.py`, `services/feishu_sync_service.py`

#### 当前实现

**`feishu_client.py` L63-64（初始化时）：**
```python
if not self._app_id or not self._app_secret:
    logger.warning("feishu_not_configured", msg="Feishu App ID or Secret not set")
```
✅ 优雅降级：仅 warn，不阻塞

**`feishu_client.py` L111-112（实际调用时）：**
```python
raise FeishuAuthError("Feishu App ID and App Secret must be configured")
```
英文错误消息。

**`feishu_sync_service.py` L87-100：**
```python
except FeishuApiError as exc:
    sync.error_message = f"[{exc.code}] {exc.msg}"  # 英文
except Exception as exc:
    sync.error_message = str(exc)  # 原始异常
```

#### 评估结果 🟢（降级路径）/ 🟡（错误消息）

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟡 | 所有错误消息为英文 |
| 可理解性 | 🟡 | 部分消息暴露技术细节（如 Feishu API error code） |
| 解决建议 | 🔴 | 无提示用户如何配置 FEISHU_APP_ID/FEISHU_APP_SECRET |
| 优雅降级 | 🟢✅ | 初始化时仅 warn；同步时捕获异常不阻塞整体流程 |

---

### 2.7 API 路由通用错误处理

**涉及文件：** `core/exceptions.py`, 所有 `api/*.py` 文件

#### 当前实现

**`core/exceptions.py`（全局异常处理器）：**
```python
400 → {"detail": "Bad request", "error": str(exc)}       # 英文
404 → {"detail": "Not found"}                             # 英文
422 → {"detail": str(exc)}                                # 直接暴露异常
500 → {"detail": "Internal server error"}                 # 过於通用
```

**API 路由：**
所有 11 个 API 路由文件一致使用英文错误消息：
- `"Product not found"` / `"Task not found"` / `"Version not found"`
- `"Discovery session not found"` / `"Collection template not found"` / `"Candidate not found"`
- `"Sync record not found"` / `"Scheduled collection not found"`
- `"Product with key '...' already exists"`

共 15+ 处 `HTTPException(status_code=404, detail=...)`，全部英文。

**`task_service.py` L227-228：** 验证异常时：
```python
error_message=str(exc)  # 原始 Python 异常暴露给用户
```

#### 评估结果 🟡

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🔴 | **全部英文**，国内企业系统不友好 |
| 可理解性 | 🟡 | 技术用户可理解，但对非技术运营人员不够友好 |
| 解决建议 | 🔴 | 无任何建议 |
| 一致性 | 🟢 | 404 错误模板一致 |

---

### 2.8 采集管道通用异常

**涉及文件：** `tasks/collection.py`

#### 当前实现

**`_do_collect` L226-244：**
```python
except Exception as exc:
    error_message=str(exc)  # 原始异常暴露
    await repo.update_status(..., error_message=str(exc))
```

**`_do_clean` L300-305：** 同 `str(exc)` 原始暴露。

**`_do_extract` L369-374：** 同 `str(exc)` 原始暴露。

失败时错误消息均来自原始 Python 异常，可能包含：
- 技术栈溢出
- 数据库连接字符串片段
- API Key 前缀（若 LLM 调用失败）

#### 评估结果 🟡

| 维度 | 评分 | 说明 |
|------|------|------|
| 语言 | 🟡 | 取决于异常来源，可能混杂英文技术信息 |
| 可理解性 | 🔴 | 原始异常对非技术人员完全不可理解 |
| 解决建议 | 🔴 | 无任何建议 |
| 安全风险 | 🟡 | 可能泄露 API key 前缀等敏感信息（虽有 `_log_safe` 但 error_message 已存储到 DB） |

---

## 3. 总体评估表

| 文件 | 错误分类 | 语言 | 可理解性 | 解决建议 | 优雅降级 | 优先修复 |
|------|---------|------|---------|---------|---------|---------|
| `failure_intelligence.py` | 所有采集失败 | 🟢 中文 | 🟢 良好 | 🟢 有 | 🟢 N/A | ✅ 无需大改 |
| `direct_http.py` | DNS / 连接 / 超时 | 🟡 混合 | 🟡 可接受 | 🟢 优 | 🟢 有重试 | 🟢 基本 OK |
| `url_validator.py` | SSRF / DNS / HTTP | 🔴 英文 | 🟡 一般 | 🔴 无 | 🟡 有限 | **🔴 高** |
| `core/exceptions.py` | 全局异常 | 🔴 英文 | 🟡 一般 | 🔴 无 | 🟢 有 | **🟡 中** |
| `feishu_client.py` | 飞书鉴权 | 🔴 英文 | 🟡 一般 | 🔴 无 | 🟢 优 | 🟡 中 |
| `feishu_sync_service.py` | 同步失败 | 🔴 英文 | 🟡 一般 | 🔴 无 | 🟢 优 | 🟡 中 |
| `task_service.py` | 验证失败 | 🔴 英文 | 🟡 一般 | 🔴 无 | 🟢 优 | **🔴 高** |
| `tasks/collection.py` | 采集/清洗/提取异常 | 🟡 混合 | 🔴 原始异常 | 🔴 无 | 🟢 Celery 重试 | **🔴 高** |
| `api/*.py` (11 files) | 404/422/409 | 🔴 全英文 | 🟡 可读 | 🔴 无 | 🟢 标准 HTTP | **🔴 高** |
| `selector.py` | 采集器选择 | 🔴 英文 | 🟡 一般 | 🔴 无 | 🟢 有 fallback | 🟡 中 |
| `providers/config.py` | 提供商缺失 | 🔴 无验证 | 🔴 **无提示** | 🔴 无 | 🟢 mock 兜底 | **🔴 高** |
| JS 挑战检测 | Cloudflare WAF | 🔴 **未实现** | 🔴 无检测 | 🔴 无 | 🟡 selector 会尝试 Playwright | **🔴 高** |

---

## 4. 具体修复建议

### P0 — 必须立即修复

#### 🔴 4.1 添加 Cloudflare / WAF JS 挑战检测

**问题：** 没有专门的 Cloudflare JS 挑战检测，用户不知道页面被 WAF 拦截需要浏览器渲染。

**修改文件：** `failure_intelligence.py`, `url_validator.py`

**建议：**
1. `failure_intelligence.py` 新增 `JS_CHALLENGE` 分类：
   ```python
   "JS_CHALLENGE": {
       "failure_type": "js_challenge",
       "retryable": True,
       "suggested_next": "retry_playwright",
       "user_visible_message": "检测到 JS 质询验证（如 Cloudflare），请启用浏览器渲染采集器",
   }
   ```
2. `url_validator.py` 增加 Cloudflare 特征检测（`__cf_chl_opt`、`cf-wrapper`、`/cdn-cgi/` 等）
3. `failure_intelligence.py` 的 `analyze_failure()` 增加对应检测分支
4. `direct_http.py` 响应体检测：若包含 Cloudflare 特征，标记为 `JS_CHALLENGE`

---

#### 🔴 4.2 所有 API 路由：错误消息本地化为中文

**问题：** 15+ 处 `HTTPException(status_code=404, detail="...")` 全为英文。

**修改文件：** 所有 `api/*.py` 文件

**建议：** 统一将 error detail 改为中文：
| 英文 | 中文 |
|------|------|
| "Product not found" | "产品不存在" |
| "Task not found" | "采集任务不存在" |
| "Version not found" | "版本不存在" |
| "Discovery session not found" | "发现会话不存在" |
| "Collection template not found" | "采集模板不存在" |
| "Candidate not found" | "采集候选不存在" |
| "Sync record not found" | "同步记录不存在" |
| "Scheduled collection not found" | "定时采集不存在" |
| "Product with key '...' already exists" | "产品唯一键 '{key}' 已存在" |

---

#### 🔴 4.3 URL 验证器错误消息本地化 + 添加解决建议

**修改文件：** `url_validator.py`, `task_service.py`

**`url_validator.py` `_fail()` 修改建议：**
| 错误码 | 当前英文消息 | 建议中文消息 | 补充建议 |
|--------|------------|------------|---------|
| URL_INVALID | "Invalid URL format" | "URL 格式无效" | "请检查链接是否正确，必须以 http:// 或 https:// 开头" |
| URL_FORBIDDEN | "Access to private IP is forbidden" | "无法访问该地址" | "该链接指向内网地址，已被安全策略拦截" |
| DNS_RESOLUTION_FAILED | "DNS resolution or connection failed" | "域名解析失败" | "网站可能已关闭、域名已过期，或网络不可达" |
| FETCH_HTTP_ERROR | "HTTP {code}" | "服务器返回 HTTP 状态码 {code}" | "请检查目标网站是否正常运行" |
| ROBOTS_BLOCKED | "Blocked by robots.txt: {url}" | "被 robots.txt 禁止采集" | "该网站设置了爬虫限制规则，无法自动采集" |
| LOGIN_REQUIRED | "Login page detected..." | "需要登录才能访问" | "该页面需要账号登录，请改为粘贴文本内容" |
| CAPTCHA_DETECTED | "CAPTCHA detected..." | "检测到人机验证" | "网站设置了验证码，建议使用浏览器渲染模式" |

**同时，`UrlValidationResult` schema 应增加一个可选 `suggested_action` 字段**，供前端展示可操作建议。

---

#### 🔴 4.4 提供商缺失启动验证

**修改文件：** `main.py` 或新增启动钩子

**建议：** 在 FastAPI lifespan startup 中添加检查：
```python
if settings.SEARCH_PROVIDER in ("", "mock"):
    logger.warning("search_provider_not_configured",
                   msg="搜索提供商未配置（当前使用 mock），请设置 SEARCH_PROVIDER 环境变量")
if settings.LLM_PROVIDER in ("", "mock"):
    logger.warning("llm_provider_not_configured",
                   msg="LLM 提供商未配置（当前使用 mock），请设置 LLM_PROVIDER + LLM_API_KEY")
if not settings.FEISHU_APP_ID:
    logger.warning("feishu_not_configured",
                   msg="飞书未配置（FEISHU_APP_ID 为空），同步功能不可用")
```

---

### P1 — 应尽快修复

#### 🟡 4.5 `task_service.py` 验证异常处理改进

**修改文件：** `task_service.py` `_run_validation()` 方法

**问题：** 验证过程 `validate_url()` 抛出原始异常时，`error_message=str(exc)` 直接存储未加工。

**建议：**
```python
except Exception as exc:
    user_message = "URL 验证过程中发生未知错误"
    logger.error("validation_error", task_id=str(task.id), error=str(exc))
    # 不暴露原始异常给用户
    await self._repo.update_status(
        task.id, TaskStatus.FAILED,
        error_code="VALIDATION_ERROR",
        error_message=user_message,
    )
```

---

#### 🟡 4.6 采集管道异常保护

**修改文件：** `tasks/collection.py` 中的 `_do_collect()`、`_do_clean()`、`_do_extract()`

**问题：** `except Exception as exc:` 后直接 `str(exc)` 暴露原始异常。

**建议：** 对通用异常进行处理，使用 `failure_intelligence.analyze_failure()` 生成用户可读消息，或至少使用更安全的包装：
```python
except Exception as exc:
    fi = analyze_failure(error_message=str(exc))
    user_message = fi.user_visible_message or "采集过程中发生未知错误"
    await repo.update_status(tid, TaskStatus.FAILED, 
                             error_code="COLLECT_ERROR",
                             error_message=user_message)
```

---

#### 🟡 4.7 飞书错误消息本地化

**修改文件：** `feishu_client.py`

**建议：**
```python
# L64 初始化警告
logger.warning("feishu_not_configured", msg="飞书未配置（FEISHU_APP_ID 或 FEISHU_APP_SECRET 为空）")

# L112 运行时报错
raise FeishuAuthError("飞书应用凭证未配置，请在环境变量中设置 FEISHU_APP_ID 和 FEISHU_APP_SECRET")

# L124 token 获取失败
raise FeishuAuthError(f"获取飞书访问令牌失败：{data.get('msg', '')}")
```

---

#### 🟡 4.8 全局异常处理器本地化

**修改文件：** `core/exceptions.py`

**建议：**
```python
# 400
{"detail": "请求参数有误", "error": str(exc)}
# 404
{"detail": "请求的资源不存在"}
# 422
{"detail": "输入参数验证失败，请检查请求数据格式"}
# 500
{"detail": "服务器内部错误，请联系管理员"}
```

---

#### 🟡 4.9 `url_validator.py` login/captcha/access_denied 关键词本地化

**修改文件：** `url_validator.py`

**问题：** 检测关键词虽包含中文，但返回的 warning 消息为英文。

**建议：**
```python
if _LOGIN_KEYWORDS.search(page_text):
    content_warnings.append("检测到登录页面，该页面需要账号认证")
if _CAPTCHA_KEYWORDS.search(page_text):
    content_warnings.append("检测到人机验证（验证码），自动采集可能被拦截")
if _ACCESS_DENIED_KEYWORDS.search(page_text):
    content_warnings.append("检测到访问被拒绝/禁止访问页面")
```

---

### P2 — 低优先级改进

#### 🟢 4.10 `selector.py` blocked source 提示本地化

```python
# 当前英文
reason="Source risk level is 'blocked' — no collector allowed"
# 建议中文
reason="该来源已被标记为高风险，已禁止自动采集"
```

#### 🟢 4.11 `failure_intelligence.py` 扩展 BLOCKED_SOURCE 的分支

添加子类型以区分：
- `ROBOTS_TXT_BLOCKED` — "被 robots.txt 禁止采集"
- `LOGIN_REQUIRED` — "需要登录认证"
- `JS_CHALLENGE` — "触发 JS 质询验证"

---

## 5. 总体结论

### 评分总览

| 维度 | 评分 | 说明 |
|------|------|------|
| ❌ 语言一致性 | 3/10 | 绝大多数错误消息为英文，仅 `failure_intelligence.py` 有高质量中文 |
| ✅ 解决建议 | 6/10 | `failure_intelligence.py` 做得很好；其他模块均缺失 |
| ✅ 优雅降级 | 8/10 | 飞书、提供商 mock/stub、Celery 重试机制完善 |
| ❌ 特殊场景覆盖 | 4/10 | JS 挑战检测完全缺失；Cloudflare WAF 未识别 |
| ❌ 原始异常保护 | 5/10 | 多处直接 `str(exc)` 暴露技术细节给用户 |

### 总体评分：5.2/10 ⚠️ （需要针对性改进）

### 工作量估算

| 优先级 | 项目 | 预估工时 | 涉及文件数 |
|--------|------|---------|-----------|
| P0 | JS 挑战检测 | 2-3h | 3 |
| P0 | API 错误本地化 | 1-2h | 12 |
| P0 | URL 验证器重写 | 2-3h | 2 |
| P0 | 启动验证 | 0.5h | 1 |
| P1 | 管道异常保护 | 1-2h | 2 |
| P1 | 飞书消息本地化 | 0.5h | 1 |
| P1 | 全局异常本地化 | 0.5h | 1 |
| P2 | 其他提示本地化 | 0.5h | 2 |
| **总计** | | **8-13h** | **约 15 个文件** |

---

*报告结束*
