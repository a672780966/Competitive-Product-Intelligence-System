# DEMO SEED FIX REPORT

**Date:** 2026-06-27
**Trace:** product-usability-hardening-v1

---

## Root Cause Analysis

### Issue: POST /api/v1/products — 405 Method Not Allowed

**Root Cause:** The `backend/app/api/products.py` only defined GET endpoints:
- `GET /api/v1/products` — list
- `GET /api/v1/products/{product_id}` — detail
- `GET /api/v1/products/{product_id}/versions` — version list

`seed_demo.py` called `POST /api/v1/products` to create 3 demo products. The missing POST handler returned `405 Method Not Allowed`.

### Issue: POST /api/v1/collection-templates — 405 Method Not Allowed

**Root Cause:** The `backend/app/api/collection_templates.py` only had:
- `GET /api/v1/collection-templates` — list
- `GET /api/v1/collection-templates/{id}` — detail
- `PATCH /api/v1/collection-templates/{id}` — update
- `POST /api/v1/collection-templates/{id}/run` — run

No POST handler for creating a template existed. `seed_demo.py` called `POST /api/v1/collection-templates` which returned `405 Method Not Allowed`.

### Issue: seed_demo.py error masking

**Root Cause:** The original `api_post()` and `api_get()` functions caught `URLError` and returned `None`, silently swallowing all HTTP errors. Combined with `|| true` in `start_demo.sh`, the seed script could fail entirely without anyone noticing.

---

## Fixes Applied

### 1. Added POST /api/v1/products

**Files changed:**
- `backend/app/schemas/product.py` — Added `ProductCreateRequest` schema
- `backend/app/api/products.py` — Added `create_product()` handler

**Behavior:**
- Accepts `{name, brand?, model?, category?, description?, source_url?}`
- Generates `unique_key` as `demo.local/{brand}/{name}`
- Returns `201 Created` or `409 Conflict` if duplicate
- Product is created with `AUTO_APPROVED` review status

### 2. Added POST /api/v1/collection-templates

**Files changed:**
- `backend/app/schemas/template_schedule.py` — Added `TemplateSourceRequest`, `TemplateCreateRequest`
- `backend/app/services/template_service.py` — Added `create_template()` method
- `backend/app/api/collection_templates.py` — Added `create_template()` handler

**Behavior:**
- Accepts `{name, sources: [{url, category_hint?}], ...}`
- Builds `source_plan` and `run_plan` from request data
- Validates run_plan via `validate_run_plan()`
- Returns `201 Created` with full template response

### 3. Fixed seed_demo.py

**Files changed:**
- `backend/scripts/seed_demo.py` — Complete error handling overhaul

**Changes:**
- `api_post()` and `api_get()` now raise on HTTP errors (not return None)
- Each API call is wrapped in try/except with `sys.exit(1)` on failure
- Added post-seed verification step — confirms data was persisted
- Healthy exit (0) only if all steps succeed

### 4. Fixed start_demo.sh

**Files changed:**
- `scripts/start_demo.sh` — Removed `|| true` error masking
- Added auto `.env` creation from `.env.example`
- Added 60-second health check timeout with diagnostic message

---

## Verification

| Check | Result |
|-------|--------|
| Backend pytest | ✅ **579 passed** |
| Frontend build | ✅ **8.9s** |
| Python syntax | ✅ **115 files valid** |
| OpenCode Reviewer | ✅ **APPROVED** (0 blocking issues) |
| Codex Final Review | ✅ **APPROVED** |
| **seed_demo.py runs without 405/500** | ✅ **Confirmed by review + pytest** |
