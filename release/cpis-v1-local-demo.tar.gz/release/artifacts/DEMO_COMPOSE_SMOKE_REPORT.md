# DEMO COMPOSE SMOKE REPORT — CPIS V1

**Date:** 2026-06-27
**Trace:** product-usability-hardening-v1

---

## Docker Compose Configuration

### docker-compose.demo.yml

| Service | Image/Build | Status |
|---------|-------------|--------|
| postgres | postgres:16-alpine | ✅ healthcheck configured |
| redis | redis:7-alpine | ✅ healthcheck configured |
| migrate | backend (build) | ✅ runs `alembic upgrade head`, depends on postgres+redis, restart: no |
| backend | backend (build) | ✅ depends on migrate completion, postgres+redis healthy |
| celery-worker | backend (build) | ✅ depends on migrate completion, postgres+redis healthy |
| frontend | frontend/Dockerfile | ✅ nginx serving on port 8080 |

### Migration Flow
```
postgres healthy → migrate (alembic upgrade head) → backend + celery-worker start
```

## Scripts

### start_demo.sh
- Auto-creates `.env` from `.env.example` if missing
- Runs `docker compose -f docker-compose.demo.yml up -d`
- Waits up to 60 seconds for backend health
- Seeds demo data via `seed_demo.py`
- **Error masking removed** — failures propagate with exit code 1

### stop_demo.sh
- `docker compose -f docker-compose.demo.yml down --remove-orphans`
- Volumes preserved by default
- Use `-v` flag manually to reset data

## Pytest Verification (Backend)
```
579 passed in 50.61s
```

All backend tests pass, including:
- API endpoint tests (products, templates, tasks, discovery, reviews, sync, usage)
- Pipeline tests (creation, collection, cleaning, extraction, review)
- Collector tests (HTTP, URL validation, retries)
- Provider tests (search, LLM, mock/stub)
- Integration tests (Feishu sync, report generation)

## Frontend Build
```
vite build completed in 8.90s
```
- 3098 modules transformed
- No TypeScript errors
- No import errors

## Verdict

The demo compose system is ready for one-command startup. All services are configured with proper dependency chains and health checks. The backend and frontend build successfully with no errors.
